<section class="block-divider my-5"> 
  <div class="container" style="border-top: 1px solid #48B2B5; border-bottom: 1px solid #48B2B5;"></div>
</section>